var StoryState;
var Character;
var Campaign;

function getJSON(name){
  $.ajax({
    url: "/console",
    type: "GET",
    data: {
            name:Campaign + "/" + name
          },
    success: function(data){
        if (data.error)
          console.log("bad");
        else
          console.log("good");
        console.log(data);
        let out = generateOptionsList(data);
        $("#console").append(data.text + "<br>");
        $("#console").append(out + "<br>");
        StoryState = data;
        window.scrollBy(0, 100000); 
      } ,     
    dataType: "json"
  });   
  $("#command").val("");

  return false;
}

function setCampaign () {
  console.log("hi");
  Campaign = $("#campaignName").val();
  $.ajax({
    url: "/console",
    type: "GET",
    data: {
            name:Campaign+"/campaign"
          },
    success: function(data){
        console.log(data);
        getJSON(data.start);
      } ,     
    dataType: "json"
  });   
}

function generateOptionsList (data) {
  let str = "Choose one of the following actions: "
  for (let i = 0; i<data.exit.length; i++) {
    str = str + " " + data.exit[i].trigger + ",";
  }
  return (str);
}

function doCommand() {
  let a = false;
  for (let i = 0; i<StoryState.exit.length; i++) {
    if (StoryState.exit[i].trigger == $("#command").val()) {
      $("#console").append("You " + $("#command").val() + ". <br>")
      getJSON(StoryState.exit[i].out);
      console.log(StoryState.exit[i].out);
      a = true;
    }
  }
  if (!a) {
    $("#command").val("");
    $("#console").append("Invalid entry." + "<br>");
  }
}

$(document).ready(function(){ 
  setCampaign();
  //getJSON("start"); // Initial Story State 

  $("#sendCommand").click(doCommand);
  $("#doCampaign").click(setCampaign);
});

$("#command").on('keyup', function (e) { 
  if (e.key === 'Enter' || e.keyCode === 13) { 
    doCommand(); 
  } 
});