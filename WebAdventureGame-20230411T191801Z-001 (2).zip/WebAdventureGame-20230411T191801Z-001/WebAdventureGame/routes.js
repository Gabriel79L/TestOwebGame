let path = require("path");
let express = require("express");
let game = require("./gameLoader");
let campaignM = require("./campaignManager");

//Look at below web page for info on express.Router()
//https://scotch.io/tutorials/learn-to-use-the-new-router-in-expressjs-4
let router = express.Router();

//request is info sending to server from client.
//response is info sending to client from server.

router.get("/",function(req,res){
    res.sendFile(path.resolve(__dirname + "/public/views/index.html"));  //changed
});

router.get("/game",function(req,res){
    res.sendFile(path.resolve(__dirname + "/public/views/console.html"));  //changed
});

router.get('/console', function(req, res){

    game.doStoryState(req.query.name, function(data){
    	res.json(data);
    });

});

router.get('/storyStateUpload', function(req, res){

    console.log(req.query.filename);
    campaignM.createStoryState(req.query.campaign, req.query.filename, req.query.storystate);

    res.json({error: false});
});

router.get('/createCampaign', function(req, res){
    console.log(req.query);
    campaignM.createCampaign(req.query);

    res.json({error: false});
});

router.get("/editor",function(req,res){
    res.sendFile(path.resolve(__dirname + "/public/views/campaignMaker.html"));  //changed
});



module.exports = router;